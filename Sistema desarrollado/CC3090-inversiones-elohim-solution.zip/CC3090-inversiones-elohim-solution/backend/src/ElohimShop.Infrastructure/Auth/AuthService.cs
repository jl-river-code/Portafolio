using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using ElohimShop.Application.Admin;
using ElohimShop.Application.Auth;
using ElohimShop.Domain.Platform;
using ElohimShop.Infrastructure.Persistence;
using ElohimShop.Infrastructure.Security;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using PlatformUser = ElohimShop.Domain.Platform.User;

namespace ElohimShop.Infrastructure.Auth;

public class AuthService : IAuthService
{
    private const int TokenLifetimeMonths = 1;
    private readonly PlatformDbContext _dbContext;
    private readonly IConfiguration _configuration;
    private readonly ITenantProvider _tenantProvider;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly IGoogleTokenValidator _googleTokenValidator;

    public AuthService(
        PlatformDbContext dbContext,
        IConfiguration configuration,
        ITenantProvider tenantProvider,
        IHttpContextAccessor httpContextAccessor,
        IGoogleTokenValidator googleTokenValidator)
    {
        _dbContext = dbContext;
        _configuration = configuration;
        _tenantProvider = tenantProvider;
        _httpContextAccessor = httpContextAccessor;
        _googleTokenValidator = googleTokenValidator;
    }

    public async Task<AuthResponseDto> RegisterAsync(RegisterRequestDto request, CancellationToken cancellationToken)
    {
        if (request.TipoUsuario == "administrador" || request.TipoUsuario == "staff")
        {
            throw new InvalidOperationException("No tenés permisos para registrar personal de la tienda.");
        }

        var tenantId = _tenantProvider.GetTenantId();
        if (string.IsNullOrWhiteSpace(tenantId))
        {
            throw new InvalidOperationException("Se requiere el tenant (tienda_id) para registrar un cliente.");
        }

        var email = request.Correo.Trim().ToLowerInvariant();
        var correoExistente = await _dbContext.Users
            .IgnoreQueryFilters()
            .AnyAsync(u => u.Email == email && (u.TiendaId == tenantId || u.TipoUsuario == "staff" || u.TipoUsuario == "administrador"), cancellationToken);

        if (correoExistente)
        {
            throw new InvalidOperationException("El correo ya está registrado en esta tienda o como administrador en la plataforma.");
        }

        var hashedPassword = PasswordHashing.Hash(request.Contrasena);

        var usuario = new PlatformUser
        {
            Id = Guid.NewGuid().ToString(),
            Name = $"{request.Nombre} {request.Apellido}".Trim(),
            Email = email,
            EmailVerified = false,
            TiendaId = tenantId,
            TipoUsuario = "cliente",
            Telefono = request.Telefono,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };

        _dbContext.Users.Add(usuario);

        var account = new Account
        {
            Id = Guid.NewGuid().ToString(),
            UserId = usuario.Id,
            ProviderId = "credential",
            AccountId = email,
            Password = hashedPassword,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };

        _dbContext.Accounts.Add(account);
        await _dbContext.SaveChangesAsync(cancellationToken);

        var session = await CreateSessionAsync(usuario.Id, cancellationToken);

        var esSuperAdmin = SuperAdminHelper.IsSuperAdminEmail(
            usuario.Email,
            _configuration["SuperAdmin:Email"]);

        return new AuthResponseDto(
            usuario.Id,
            usuario.Email,
            usuario.Name,
            "cliente",
            null,
            request.TipoCliente ?? "particular",
            session.Token,
            session.ExpiresAt,
            esSuperAdmin);
    }

    public async Task<AuthResponseDto> RegisterAdminAsync(RegisterRequestDto request, CancellationToken cancellationToken)
    {
        var httpContext = _httpContextAccessor.HttpContext;
        var isAnonymous = httpContext?.User?.Identity?.IsAuthenticated != true;

        string? tenantId = null;
        if (!isAnonymous)
        {
            tenantId = _tenantProvider.GetTenantId();
        }

        var esCreadorCuenta = string.IsNullOrWhiteSpace(tenantId);

        if (!esCreadorCuenta && string.IsNullOrWhiteSpace(request.Rol))
        {
            throw new ArgumentException("El campo rol es requerido para personal de la tienda.");
        }
        if (esCreadorCuenta)
        {
            var nuevaTiendaId = Guid.NewGuid().ToString();
            var slug = $"tienda-{Guid.NewGuid().ToString().Substring(0, 8)}";
            var tienda = new Tienda
            {
                Id = nuevaTiendaId,
                Nombre = $"Tienda de {request.Nombre}",
                Slug = slug,
                Estado = "activo",
                ConfiguracionVisual = "{}",
                FechaCreacion = DateTime.UtcNow
            };
            _dbContext.Tiendas.Add(tienda);

            var sucursal = new Sucursal
            {
                Id = Guid.NewGuid().ToString(),
                TiendaId = nuevaTiendaId,
                Nombre = "Sucursal Principal",
                Direccion = request.Direccion ?? "Dirección Principal",
                Telefono = request.Telefono ?? "Teléfono Principal",
                FechaCreacion = DateTime.UtcNow
            };
            _dbContext.Sucursales.Add(sucursal);

            tenantId = nuevaTiendaId;
        }

        var email = request.Correo.Trim().ToLowerInvariant();
        var correoExistente = await _dbContext.Users
            .IgnoreQueryFilters()
            .AnyAsync(u => u.Email == email && (u.TipoUsuario == "staff" || u.TipoUsuario == "administrador" || u.TiendaId == tenantId), cancellationToken);

        if (correoExistente)
        {
            throw new InvalidOperationException("El correo ya está registrado como administrador en la plataforma o como usuario en esta tienda.");
        }

        var hashedPassword = PasswordHashing.Hash(request.Contrasena);

        var usuario = new PlatformUser
        {
            Id = Guid.NewGuid().ToString(),
            Name = $"{request.Nombre} {request.Apellido}".Trim(),
            Email = email,
            EmailVerified = false,
            TiendaId = tenantId,
            TipoUsuario = "staff",
            RolStaff = esCreadorCuenta ? "administrador" : request.Rol.Trim().ToLowerInvariant(),
            Telefono = request.Telefono,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };

        _dbContext.Users.Add(usuario);

        var account = new Account
        {
            Id = Guid.NewGuid().ToString(),
            UserId = usuario.Id,
            ProviderId = "credential",
            AccountId = email,
            Password = hashedPassword,
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };

        _dbContext.Accounts.Add(account);
        await _dbContext.SaveChangesAsync(cancellationToken);

        var session = await CreateSessionAsync(usuario.Id, cancellationToken);

        var esSuperAdmin = string.Equals(usuario.RolStaff, "superadmin", StringComparison.OrdinalIgnoreCase) ||
                           SuperAdminHelper.IsSuperAdminEmail(usuario.Email, _configuration["SuperAdmin:Email"]);

        return new AuthResponseDto(
            usuario.Id,
            usuario.Email,
            usuario.Name,
            "administrador",
            usuario.RolStaff,
            null,
            session.Token,
            session.ExpiresAt,
            esSuperAdmin);
    }

    public async Task<AuthResponseDto> LoginAsync(LoginRequestDto request, CancellationToken cancellationToken)
    {
        var email = request.Correo.Trim().ToLowerInvariant();

        // First try to find a staff/admin user globally
        var usuario = await _dbContext.Users
            .IgnoreQueryFilters()
            .FirstOrDefaultAsync(u => u.Email == email && (u.TipoUsuario == "staff" || u.TipoUsuario == "administrador"), cancellationToken);

        // If no staff/admin found, query for a client scoped to the current tenant
        if (usuario is null)
        {
            var query = _dbContext.Users.IgnoreQueryFilters().Where(u => u.TipoUsuario == "cliente");
            var tenantId = _tenantProvider.GetTenantId();
            if (!string.IsNullOrWhiteSpace(tenantId))
            {
                query = query.Where(u => u.TiendaId == tenantId);
            }
            usuario = await query.FirstOrDefaultAsync(u => u.Email == email, cancellationToken);
        }

        if (usuario is null)
        {
            throw new UnauthorizedAccessException("Credenciales inválidas.");
        }

        var account = await _dbContext.Accounts
            .IgnoreQueryFilters()
            .FirstOrDefaultAsync(a => a.UserId == usuario.Id && a.ProviderId == "credential", cancellationToken);

        if (account is null || string.IsNullOrWhiteSpace(account.Password) || !PasswordHashing.Verify(request.Contrasena, account.Password))
        {
            throw new UnauthorizedAccessException("Credenciales inválidas.");
        }

        var session = await CreateSessionAsync(usuario.Id, cancellationToken);

        var esSuperAdmin = string.Equals(usuario.RolStaff, "superadmin", StringComparison.OrdinalIgnoreCase) ||
                           SuperAdminHelper.IsSuperAdminEmail(usuario.Email, _configuration["SuperAdmin:Email"]);

        var mappedTipoUsuario = usuario.TipoUsuario == "staff" ? "administrador" : "cliente";

        return new AuthResponseDto(
            usuario.Id,
            usuario.Email,
            usuario.Name,
            mappedTipoUsuario,
            usuario.RolStaff,
            usuario.TipoUsuario == "cliente" ? "particular" : null,
            session.Token,
            session.ExpiresAt,
            esSuperAdmin);
    }

    public async Task<AuthResponseDto> LoginWithGoogleAsync(
        GoogleAuthRequestDto request,
        CancellationToken cancellationToken)
    {
        var requestedUserType = request.TipoUsuario.Trim().ToLowerInvariant();
        if (requestedUserType is not ("cliente" or "administrador"))
        {
            throw new ArgumentException("El tipo de usuario debe ser cliente o administrador.");
        }

        var payload = await _googleTokenValidator.ValidateAsync(request.IdToken, cancellationToken);
        if (!payload.EmailVerified || string.IsNullOrWhiteSpace(payload.Email) || string.IsNullOrWhiteSpace(payload.Subject))
        {
            throw new UnauthorizedAccessException("Google no pudo verificar el correo de la cuenta.");
        }

        var email = payload.Email.Trim().ToLowerInvariant();
        string? tenantId = null;
        if (requestedUserType == "cliente")
        {
            tenantId = _tenantProvider.GetTenantId();
            if (string.IsNullOrWhiteSpace(tenantId))
            {
                throw new InvalidOperationException("Se requiere el tenant (tienda_id) para acceder como cliente.");
            }

            if (!string.IsNullOrWhiteSpace(request.TiendaId) && request.TiendaId != tenantId)
            {
                throw new UnauthorizedAccessException("La tienda indicada no coincide con el contexto de la solicitud.");
            }
        }

        var linkedAccountQuery = _dbContext.Accounts
            .IgnoreQueryFilters()
            .Include(a => a.User)
            .Where(a => a.ProviderId == "google" && a.AccountId == payload.Subject);

        linkedAccountQuery = requestedUserType == "cliente"
            ? linkedAccountQuery.Where(a => a.User != null && a.User.TipoUsuario == "cliente" && a.User.TiendaId == tenantId)
            : linkedAccountQuery.Where(a => a.User != null && (a.User.TipoUsuario == "staff" || a.User.TipoUsuario == "administrador"));

        var usuario = (await linkedAccountQuery.FirstOrDefaultAsync(cancellationToken))?.User;

        if (usuario is null)
        {
            var userQuery = _dbContext.Users.IgnoreQueryFilters().Where(u => u.Email == email);
            userQuery = requestedUserType == "cliente"
                ? userQuery.Where(u => u.TipoUsuario == "cliente" && u.TiendaId == tenantId)
                : userQuery.Where(u => u.TipoUsuario == "staff" || u.TipoUsuario == "administrador");

            usuario = await userQuery.FirstOrDefaultAsync(cancellationToken);
            if (usuario is null)
            {
                usuario = requestedUserType == "cliente"
                    ? CreateGoogleClient(payload, email, tenantId!)
                    : CreateGoogleStoreAdministrator(payload, email);
                _dbContext.Users.Add(usuario);
            }

            _dbContext.Accounts.Add(new Account
            {
                Id = Guid.NewGuid().ToString(),
                UserId = usuario.Id,
                ProviderId = "google",
                AccountId = payload.Subject,
                CreatedAt = DateTime.UtcNow,
                UpdatedAt = DateTime.UtcNow
            });

            usuario.EmailVerified = true;
            usuario.Image ??= payload.Picture;
            usuario.UpdatedAt = DateTime.UtcNow;
            await _dbContext.SaveChangesAsync(cancellationToken);
        }

        var session = await CreateSessionAsync(usuario.Id, cancellationToken);
        var esSuperAdmin = string.Equals(usuario.RolStaff, "superadmin", StringComparison.OrdinalIgnoreCase) ||
                           SuperAdminHelper.IsSuperAdminEmail(usuario.Email, _configuration["SuperAdmin:Email"]);

        return new AuthResponseDto(
            usuario.Id,
            usuario.Email,
            usuario.Name,
            usuario.TipoUsuario == "cliente" ? "cliente" : "administrador",
            usuario.RolStaff,
            usuario.TipoUsuario == "cliente" ? "particular" : null,
            session.Token,
            session.ExpiresAt,
            esSuperAdmin);
    }

    public async Task LogoutAsync(string token, string usuarioId, DateTime expiresAt, CancellationToken cancellationToken)
    {
        var session = await _dbContext.Sessions
            .IgnoreQueryFilters()
            .FirstOrDefaultAsync(s => s.Token == token, cancellationToken);

        if (session != null)
        {
            _dbContext.Sessions.Remove(session);
            await _dbContext.SaveChangesAsync(cancellationToken);
        }
    }

    public Task ForgotPasswordAsync(ForgotPasswordRequestDto request, CancellationToken cancellationToken)
    {
        return Task.CompletedTask;
    }

    private static PlatformUser CreateGoogleClient(GoogleTokenPayload payload, string email, string tenantId)
    {
        return new PlatformUser
        {
            Id = Guid.NewGuid().ToString(),
            Name = payload.Name,
            Email = email,
            EmailVerified = true,
            Image = payload.Picture,
            TiendaId = tenantId,
            TipoUsuario = "cliente",
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };
    }

    private PlatformUser CreateGoogleStoreAdministrator(GoogleTokenPayload payload, string email)
    {
        var storeId = Guid.NewGuid().ToString();
        _dbContext.Tiendas.Add(new Tienda
        {
            Id = storeId,
            Nombre = $"Tienda de {payload.Name}",
            Slug = $"tienda-{Guid.NewGuid().ToString()[..8]}",
            Estado = "activo",
            ConfiguracionVisual = "{}",
            FechaCreacion = DateTime.UtcNow
        });
        _dbContext.Sucursales.Add(new Sucursal
        {
            Id = Guid.NewGuid().ToString(),
            TiendaId = storeId,
            Nombre = "Sucursal Principal",
            Direccion = "Dirección Principal",
            Telefono = "Teléfono Principal",
            FechaCreacion = DateTime.UtcNow
        });

        return new PlatformUser
        {
            Id = Guid.NewGuid().ToString(),
            Name = payload.Name,
            Email = email,
            EmailVerified = true,
            Image = payload.Picture,
            TiendaId = storeId,
            TipoUsuario = "staff",
            RolStaff = "administrador",
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };
    }

    private async Task<Session> CreateSessionAsync(string userId, CancellationToken cancellationToken)
    {
        var sessionToken = Guid.NewGuid().ToString("N") + Guid.NewGuid().ToString("N");
        var session = new Session
        {
            Id = Guid.NewGuid().ToString(),
            Token = sessionToken,
            UserId = userId,
            ExpiresAt = DateTime.UtcNow.AddMonths(TokenLifetimeMonths),
            CreatedAt = DateTime.UtcNow,
            UpdatedAt = DateTime.UtcNow
        };

        _dbContext.Sessions.Add(session);
        await _dbContext.SaveChangesAsync(cancellationToken);
        return session;
    }
}
